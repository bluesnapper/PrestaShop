/**
* 2007-2017 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    Cedric Fontaine <contact@prestashop.com>
*  @copyright 2007-2017 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
$(document).ready(function() {
	var release='2.1.9';
	if (bluesnap_error) {
		var p = $("#bluesnap_payment_module").offset();
		$('.payment-options').find("input[data-module-name='bluesnap']").prop('checked', 'checked');
		$('.payment-options').find("input[data-module-name='bluesnap']").trigger('change');
		$(window).scrollTop(p.top);
	}
	$('#usesaved').click(function(event) { event.preventDefault(); $('#bluesnap-payment-form-saved').show(); $('#bluesnap-payment-form').hide(); });
	$('#addnew').click(function(event) { event.preventDefault(); $('#bluesnap-payment-form-saved').hide(); $('#bluesnap-payment-form').show(); });
	var bsObj = {
		onFieldEventHandler: {
			onFocus: function(tagId) {
				if (tagId == "ccn") {
						$( "#card-number" ).addClass( "hosted-field-focus" );
					 } else if (tagId == "exp") {
						$( "#exp-date" ).addClass( "hosted-field-focus" ); 
				} else if (tagId == "cvv") {
						$( "#cvv" ).addClass( "hosted-field-focus" );
				}  
			}, // Handle focus
			onBlur: function(tagId) {
				if (tagId == "ccn") {
				  $( "#card-number" ).removeClass( "hosted-field-focus" );
				} else if (tagId == "exp") {
				  $( "#exp-date" ).removeClass( "hosted-field-focus" ); 
				} else if (tagId == "cvv") {
				  $( "#cvv" ).removeClass( "hosted-field-focus" );
				}								
			}, // Handle blur 
			onError: function(tagId, errorCode, errorDescription) {
				if (tagId == "ccn" && errorCode == "001") {
				  $( "#card-number" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" );
				  $( "#card-help" ).text(translations['valid_cc']);
				} else if (tagId == "exp" && errorCode == "003") {
				  $( "#exp-date" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" ).parent().next('span').text(translations['expiration_cc']); 
				} else if (tagId == "cvv" && errorCode == "002" ) {
				  $( "#cvv" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" ).parent().next('span').text(translations['cvv_cc']);
				}
				if (errorCode == "22013") {
					$( "#card-number, #exp-date, #cvv" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" );
					$('#bluesnaperror').show();
					$('#unsupported').show();
					$('#bluesnap-ajax-loader').hide();
				} else if (errorCode == "400") {
					$( "#card-number, #exp-date, #cvv" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" );
					$('#bluesnaperror').show();
					$('#tokenexpired').show();
					$('#bluesnap-ajax-loader').hide();
				} else if (errorCode == "403" || errorCode == "404" || errorCode == "500") {
					$( "#card-number, #exp-date, #cvv" ).removeClass( "hosted-field-focus hosted-field-valid" ).addClass( "hosted-field-invalid" );
					$('#bluesnaperror').show();
					$('#fatal').show();
					$('#bluesnap-ajax-loader').hide();
				} else {
					$('#payment-confirmation > .ps-shown-by-js > button').prop('disabled', true);
					$('#bluesnap-ajax-loader').hide();
				}
			}, // Handle a change in validation
			onType: function(tagId, cardType) {
				 $('.cc-icon').removeClass('enable').removeClass('disable').addClass('disable');
				if (cardType == "AmericanExpress") { 
					$('#BSAmericanExpress').removeClass('disable').addClass('enable');
				} else if (cardType == "CarteBleue") { 
					$('#BSVisa').removeClass('disable').addClass('enable');
				} else if (cardType == "DinersClub") { 
					$('#BSDinersClub').removeClass('disable').addClass('enable');
				} else if (cardType == "Discover") { 
					$('#BSDiscover').removeClass('disable').addClass('enable');
				} else if (cardType == "JCB") { 
					$('#BSJCB').removeClass('disable').addClass('enable');
				} else if (cardType == "MaestroUK") { 
					$('#BSVisa').removeClass('disable').addClass('enable');
				} else if (cardType == "MasterCard") { 
					$('#BSMasterCard').removeClass('disable').addClass('enable');
				} else if (cardType == "Solo") { 
					$('#BSVisa').removeClass('disable').addClass('enable');
				} else if (cardType == "Visa") { 
					$('#BSVisa').removeClass('disable').addClass('enable');
				}
			}, // cardType will give card type, and only applies to ccn: CarteBleue, Visa, MasterCard, AmericanExpress, Discover, DinersClub, JCB, Solo, MaestroUK, ChinaUnionPay
			onValid: function(tagId) {
				show = true;
				$('#conditions-to-approve input[type="checkbox"]').each(function (_, checkbox) {
	        		if (!checkbox.checked) {
	          			show = false;
	        		}
	      		});
				if (show===true && $('##bluesnap-ajax-loader').is(':hidden'))
					$('#payment-confirmation > .ps-shown-by-js > button').prop('disabled', false);
	            if (tagId == "ccn") {
	              $( "#card-number" ).removeClass( "hosted-field-focus hosted-field-invalid" ).addClass( "hosted-field-valid" );
	              $( "#card-help" ).text('');
	            } else if (tagId == "exp") {
	              $( "#exp-date" ).removeClass( "hosted-field-focus hosted-field-invalid" ).addClass( "hosted-field-valid" ).parent().next('span').text('');
	            } else if (tagId == "cvv") {
	              $( "#cvv" ).removeClass( "hosted-field-focus hosted-field-invalid" ).addClass( "hosted-field-valid" ).parent().next('span').text('');
	            }									
			}, // Handle a change in validation
		},
    style: {
        // Styling all Hosted Payment Field inputs
        "input": {
            "font-size": "14px",
			"font-family": "Helvetica Neue,Helvetica,Arial,sans-serif",
			"line-height": "1.42857143",
			"color": "#555"
        },
        "select": {
        	"line-height":"2"
        },
        // Styling a specific field
        /*"#ccn": {
            
        },*/
        
        // Styling Hosted Payment Field input state
        ":focus": {
            "color": "#555"
        }
    },
		ccnPlaceHolder: "1234 5678 9012 3456", //for example
		cvvPlaceHolder: "123", //for example
		expPlaceHolder: "00/00", //for example
		expDropDownSelector : true
	};
	bluesnap.hostedPaymentFieldsCreation (bluesnap_token, bsObj);
	$('#payment-confirmation > .ps-shown-by-js > button').click(function(event) {
	    var myPaymentMethodSelected = $('.payment-options').find("input[data-module-name='bluesnap']").is(':checked');
	     
	    if (myPaymentMethodSelected){
	    	event.preventDefault();
			if ( $('#bluesnap-payment-form').css('display') == 'none' ){
				$('#payment-confirmation > .ps-shown-by-js > button').prop('disabled', true);
				$('#bluesnap-ajax-loader').show();
				$('#unsupported').hide();
				$('#fatal').hide();
				$('#tokenexpired').hide();
				$('#bluesnap_type').val('vaulted');
				$('#bluesnap-form').submit();
			}

			if ( $('#bluesnap-payment-form-saved').css('display') == 'none' ){
				$('#payment-confirmation > .ps-shown-by-js > button').prop('disabled', true);
				$('#bluesnap-ajax-loader').show();

				bluesnap.submitCredentials(function(cardData){
					$('#bluesnap_card-last-four-digits').val(cardData.last4Digits);
					$('#bluesnap_card-type').val(cardData.ccType);
					$('#bluesnap_type').val('new');
					$('#unsupported').hide();
					$('#tokenexpired').hide();
					$('#fatal').hide();
					$('#bluesnap-form').submit();
				});
			}
	    }	     
	});
});
