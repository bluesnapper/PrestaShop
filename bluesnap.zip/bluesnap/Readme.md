BlueSnap is a global payment gateway and so much more.
We offer the widest global support in the industry plus 110 different payment types including all of Tier 1 credit cards, diner cards, PayPal, E-checks and wire transfers.
PrestaShop and BlueSnap help shoppers make purchases easily and securely with the free BlueSnap module.